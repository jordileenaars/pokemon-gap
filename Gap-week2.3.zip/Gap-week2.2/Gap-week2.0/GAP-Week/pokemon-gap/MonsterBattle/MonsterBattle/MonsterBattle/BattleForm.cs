using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MonsterBattle
{
    public partial class BattleForm : Form
    {
        Random randomGenerator;
        bool enemyDead;

        public BattleForm()
        {
            InitializeComponent();

            randomGenerator = new Random();
        }

        private void attackButton_Click(object sender, EventArgs e)
        {
            if (!enemyDead)
            {
                enemyPictureBox.Tag = enemyPictureBox.Image;
                enemyPictureBox.Image = Properties.Resources.attack_lightning;

                attackButton.Enabled = false;
                attackTimer.Start();

                screenShakeTimer.Start();

 
                    enemyHealthPictureBox.Width -= 35;
                


            }
            else
            {
                MessageBox.Show("You can not strike Charizard whilst he is already down.");
            }
        }

        

        private void screenShakeTimer_Tick(object sender, EventArgs e)
        {
            this.Top += randomGenerator.Next(-5, 6);
            this.Left += randomGenerator.Next(-5, 6);
        }

        private void button2_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void run_button_Click(object sender, EventArgs e)
        {
            System.Media.SoundPlayer player = new System.Media.SoundPlayer(@"C:\Users\stijn\OneDrive\Documenten\school\L1\periode 2\pokemon-gap\Gap-week2.2\Gap-week2.0\GAP-Week\pokemon-gap\Run_Sound_Effect_For_Vines-yIp5Q2cRf6g.wav");
            player.PlaySync();

            MessageBox.Show("you ran away");

            this.Close();
        }

        

        private void enemyHealthPictureBox_Click(object sender, EventArgs e)
        {
            int[] attackreseiver = new int[100];
            {
                attackreseiver [0] -= 35;
                attackreseiver [1] -= 20;
                attackreseiver [2] -= 5;
                attackreseiver [3] -= 28;
            }
        }

        private void ancientAttackButton_Click(object sender, EventArgs e)
        {
            if (!enemyDead)
            {
                enemyPictureBox.Tag = enemyPictureBox.Image;
                enemyPictureBox.Image = Properties.Resources.attack_power;

                attackButton.Enabled = false;
                attackTimer.Start();

                screenShakeTimer.Start();


                enemyHealthPictureBox.Width -= 20;



            }
            else
            {
                MessageBox.Show("You can not strike Charizard whilst he is already down.");
            }
        }

        

        private void chargeAttackButton_Click(object sender, EventArgs e)
        {
            if (!enemyDead)
            {
                enemyPictureBox.Tag = enemyPictureBox.Image;
                enemyPictureBox.Image = Properties.Resources.attack_charge;

                attackButton.Enabled = false;
                attackTimer.Start();

                screenShakeTimer.Start();


                enemyHealthPictureBox.Width -= 10;



            }
            else
            {
                MessageBox.Show("You can not strike Charizard whilst he is already down.");
            }
        }

        private void pluckAttackButton_Click(object sender, EventArgs e)
        {
            if (!enemyDead)
            {
                enemyPictureBox.Tag = enemyPictureBox.Image;
                enemyPictureBox.Image = Properties.Resources.attack_pluck;

                attackButton.Enabled = false;
                attackTimer.Start();

                screenShakeTimer.Start();


                enemyHealthPictureBox.Width -= 50;



            }
            else
            {
                MessageBox.Show("You can not strike Charizard whilst he is already down.");
            }
        }



        private void attackTimer_Tick(object sender, EventArgs e)
        {

            screenShakeTimer.Stop();
            attackTimer.Stop();
            attackButton.Enabled = true;

            enemyPictureBox.Image = (Image)enemyPictureBox.Tag;


            //als tweede aanval plaatsvind dan

            if (enemyHealthPictureBox.Width <= 0)
            {
                MessageBox.Show("Charizard has fainted!");
                enemyDead = true;
                enemyPictureBox.Image = null;
            }
        }

        
    }
}


