using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MonsterBattle
{
    public partial class BattleForm : Form
    {
        Random randomGenerator;
        bool enemyDead;

        public BattleForm()
        {
            InitializeComponent();

            randomGenerator = new Random();
        }

        private void attackButton_Click(object sender, EventArgs e)
        {
            if (!enemyDead)
            {
                enemyPictureBox.Tag = enemyPictureBox.Image;
                enemyPictureBox.Image = Properties.Resources.attack_lightning;

                attackButton.Enabled = false;
                attackTimer.Start();

                screenShakeTimer.Start();

 
                    enemyHealthPictureBox.Width -= 35;

                if (enemyHealthPictureBox.Width >= 70)
                {
                    enemyHealthPictureBox.Image = Properties.Resources.bar_healthy;

                }
                else if (enemyHealthPictureBox.Width <= 70 && enemyHealthPictureBox.Width >= 25)
                {
                    enemyHealthPictureBox.Image = Properties.Resources.bar_damaged;
                }
                else if (enemyHealthPictureBox.Width <= 25)
                {
                    enemyHealthPictureBox.Image = Properties.Resources.bar_low;
                }


            }
            else
            {
                MessageBox.Show("You can not strike Charizard whilst he is already down.");
            }
        }

        

        private void screenShakeTimer_Tick(object sender, EventArgs e)
        {
            this.Top += randomGenerator.Next(-5, 6);
            this.Left += randomGenerator.Next(-5, 6);
        }

        private void button2_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void run_button_Click(object sender, EventArgs e)
        {
            System.Media.SoundPlayer player = new System.Media.SoundPlayer(@"C:\Users\jordi\Documents\Radius_college_AMO\Gap-week2.2\Gap-week2.0\GAP-Week\pokemon-gap/Run_Sound_Effect_For_Vines-yIp5Q2cRf6g.wav");
            player.PlaySync();

            MessageBox.Show("you ran away");

            this.Close();
        }

        

        private void enemyHealthPictureBox_Click(object sender, EventArgs e)
        {
            
           
        }


        private void ancientAttackButton_Click(object sender, EventArgs e)
        {
            if (!enemyDead)
            {
                enemyPictureBox.Tag = enemyPictureBox.Image;
                enemyPictureBox.Image = Properties.Resources.attack_power;

                ancientAttackButton.Enabled = false;
                attackTimer.Start();

                screenShakeTimer.Start();


                enemyHealthPictureBox.Width -= 20;

                if (enemyHealthPictureBox.Width >= 70)
                {
                    enemyHealthPictureBox.Image = Properties.Resources.bar_healthy;

                }
                else if (enemyHealthPictureBox.Width <= 70 && enemyHealthPictureBox.Width >= 25)
                {
                    enemyHealthPictureBox.Image = Properties.Resources.bar_damaged;
                }
                else if (enemyHealthPictureBox.Width <= 25)
                {
                    enemyHealthPictureBox.Image = Properties.Resources.bar_low;
                }
            }
            else
            {
                MessageBox.Show("You can not strike Charizard whilst he is already down.");
            }
        }

        

        private void chargeAttackButton_Click(object sender, EventArgs e)
        {
            if (!enemyDead)
            {
                enemyPictureBox.Tag = enemyPictureBox.Image;
                enemyPictureBox.Image = Properties.Resources.attack_charge;

                chargeAttackButton.Enabled = false;
                attackTimer.Start();

                screenShakeTimer.Start();


                enemyHealthPictureBox.Width -= 10;

                if (enemyHealthPictureBox.Width >= 70)
                {
                    enemyHealthPictureBox.Image = Properties.Resources.bar_healthy;

                }
                else if (enemyHealthPictureBox.Width <= 70 && enemyHealthPictureBox.Width >= 25)
                {
                    enemyHealthPictureBox.Image = Properties.Resources.bar_damaged;
                }
                else if (enemyHealthPictureBox.Width <= 25)
                {
                    enemyHealthPictureBox.Image = Properties.Resources.bar_low;
                }

            }
            else
            {
                MessageBox.Show("You can not strike Charizard whilst he is already down.");
            }
        }

        private void pluckAttackButton_Click(object sender, EventArgs e)
        {
            if (!enemyDead)
            {
                enemyPictureBox.Tag = enemyPictureBox.Image;
                enemyPictureBox.Image = Properties.Resources.attack_pluck;

                pluckAttackButton.Enabled = false;
                attackTimer.Start();

                screenShakeTimer.Start();


                enemyHealthPictureBox.Width -= 50;

            }

            if (enemyHealthPictureBox.Width >= 70)
            {
                enemyHealthPictureBox.Image = Properties.Resources.bar_healthy;

            }
            else if (enemyHealthPictureBox.Width <= 70 && enemyHealthPictureBox.Width >= 25)
            {
                enemyHealthPictureBox.Image = Properties.Resources.bar_damaged;
            }
            else if (enemyHealthPictureBox.Width <= 25)
            {
                enemyHealthPictureBox.Image = Properties.Resources.bar_low;
            }

            else
            {
                MessageBox.Show("You can not strike Charizard whilst he is already down.");
            }
        }



        private void attackTimer_Tick(object sender, EventArgs e)
        {

            screenShakeTimer.Stop();
            attackTimer.Stop();

            attackButton.Enabled = true;
            pluckAttackButton.Enabled = true;
            chargeAttackButton.Enabled = true;
            ancientAttackButton.Enabled = true;


            enemyPictureBox.Image = (Image)enemyPictureBox.Tag;


            //als tweede aanval plaatsvind dan

            if (enemyHealthPictureBox.Width <= 0)
            {
                MessageBox.Show("Charizard has fainted!");
                enemyDead = true;
                enemyPictureBox.Image = null;
            }
        }

        private void enemyPictureBox_Click(object sender, EventArgs e)
        {

        }

        private void bag_button_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }
    }
}


